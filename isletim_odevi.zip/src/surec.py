class Surec:
    def __init__(self, pid, gelis, sure, oncelik):
        self.pid = pid
        self.gelis = gelis
        self.sure = sure
        self.kalan = sure
        self.oncelik = oncelik
