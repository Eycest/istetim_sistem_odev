# FCFS algoritması
