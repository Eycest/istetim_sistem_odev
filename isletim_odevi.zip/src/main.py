# Programın başlangıç noktası

if __name__ == '__main__':
    print('CPU Zamanlama Simülasyonu')
