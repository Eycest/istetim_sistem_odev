# Ortak metrik ve yardımcı fonksiyonlar
