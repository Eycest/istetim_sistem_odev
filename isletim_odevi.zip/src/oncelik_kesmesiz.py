# Kesmesiz öncelik algoritması
