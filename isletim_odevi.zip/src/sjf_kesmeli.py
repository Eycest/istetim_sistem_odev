# Kesmeli SJF algoritması
