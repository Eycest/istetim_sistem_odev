# Kesmeli öncelik algoritması
